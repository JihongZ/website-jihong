#' code to prepare `Dataset` dataset goes here

dat <- data.frame(
  name = "jihong",
  bio = "
I am a tenure-track Assistant Professor of Educational Statistics and Research Methods (ESRM) in the Department of Counseling, Leadership, and Research Methods (CLRM) at the University of Arkansas, Fayetteville, U.S.

Previously, I was a postdoctoral fellow in the Department of Social Work at the Chinese University of Hong Kong (CUHK). My academic journey in psychometrics began with doctoral training under Dr. Jonathan Templin in the Educational Measurement and Statistics (EMS) program at the University of Iowa. I have extensive experience in educational assessment. During my master’s program at the University of Kansas, I worked as a research assistant for three years in the Kansas Assessment Program (KAP), contributing to various assessment initiatives, including Dynamic Learning Maps (DLM). Later, during my Ph.D. program, I interned at the Stanford Research Institute (SRI), where I focused on digital learning in computerized testing.

My primary research interests include empirical and methodological studies in psychological network modeling, AI in Education, Bayesian latent variable modeling, Item Response Theory modeling, and other advanced psychometric methods. My expertise lies in applying advanced statistical modeling techniques in psychology and education.
"
)
usethis::use_data(dat, overwrite = TRUE)
