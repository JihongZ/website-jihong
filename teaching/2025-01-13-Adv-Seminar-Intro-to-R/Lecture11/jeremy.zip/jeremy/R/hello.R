#' This is the function for showing the information of XXX
#'
#' @param details Want to know more
#'
#' @returns describe some basic information about XXX
#'
#' @examples
#' hello()
#'
#' @export





hello <- function(){
  message("I am a PhD student from ...")
}
